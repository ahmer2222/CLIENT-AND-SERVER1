package Vchat;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

public class Client extends JFrame {
    private JTextArea chatArea;
    private JTextField inputField, nameField;
    private JButton connectButton, sendButton;
    private Socket socket;
    private DataInputStream reader;
    private DataOutputStream writer;
    private String username;
    private boolean isConnected = false;

    public Client() {
        createUI();
    }

    private void createUI() {
        setTitle("VChat Client");
        setSize(600, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel connectionPanel = new JPanel(new BorderLayout());
        nameField = new JTextField();
        connectButton = new JButton("Connect");

        connectButton.addActionListener(e -> {
            if (!isConnected) connectToServer();
            else disconnectFromServer();
        });

        connectionPanel.add(nameField, BorderLayout.CENTER);
        connectionPanel.add(connectButton, BorderLayout.EAST);

        chatArea = new JTextArea();
        chatArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(chatArea);

        JPanel inputPanel = new JPanel(new BorderLayout());
        inputField = new JTextField();
        inputField.setEnabled(false);
        inputField.addActionListener(e -> sendMessage());

        sendButton = new JButton("Send");
        sendButton.setEnabled(false);
        sendButton.addActionListener(e -> sendMessage());

        inputPanel.add(inputField, BorderLayout.CENTER);
        inputPanel.add(sendButton, BorderLayout.EAST);

        add(connectionPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(inputPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void connectToServer() {
        username = nameField.getText().trim();
        if (username.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a username.");
            return;
        }

        try {
            socket = new Socket("localhost", 6001);
            reader = new DataInputStream(socket.getInputStream());
            writer = new DataOutputStream(socket.getOutputStream());
            writer.writeUTF(username);

            new Thread(() -> {
                try {
                    String message;
                    while ((message = reader.readUTF()) != null) {
                        chatArea.append(message + "\n");
                    }
                } catch (IOException e) {
                    chatArea.append("Disconnected from server.\n");
                } finally {
                    updateUIState(false);
                }
            }).start();

            updateUIState(true);
            chatArea.append("Connected as " + username + "\n");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Connection failed: " + e.getMessage());
        }
    }

    private void disconnectFromServer() {
        try {
            if (writer != null) writer.writeUTF("/quit");
            if (socket != null) socket.close();
        } catch (IOException e) {
            chatArea.append("Error during disconnect.\n");
        } finally {
            updateUIState(false);
        }
    }

    private void updateUIState(boolean connected) {
        isConnected = connected;
        nameField.setEnabled(!connected);
        inputField.setEnabled(connected);
        sendButton.setEnabled(connected);
        connectButton.setText(connected ? "Disconnect" : "Connect");
    }

    private void sendMessage() {
        String message = inputField.getText().trim();
        if (!message.isEmpty()) {
            try {
                writer.writeUTF(message);
                inputField.setText("");
            } catch (IOException e) {
                chatArea.append("Message failed to send.\n");
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Client::new);
    }
}