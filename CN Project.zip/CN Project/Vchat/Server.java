package Vchat;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class Server {
    private static final Map<String, ClientHandler> clients = Collections.synchronizedMap(new HashMap<>());

    private static JTextField textField;
    private static JPanel chatPanel;
    private static Box verticalBox = Box.createVerticalBox();
    private static JFrame frame;
    private static JComboBox<String> clientList;

    public Server() {
        frame = new JFrame("Server");
        frame.setSize(500, 700);
        frame.setLayout(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel header = new JPanel(null);
        header.setBackground(new Color(7, 94, 84));
        header.setBounds(0, 0, 500, 70);

        JLabel label = new JLabel("Server");
        label.setForeground(Color.WHITE);
        label.setFont(new Font("SAN_SERIF", Font.BOLD, 24));
        label.setBounds(20, 20, 100, 30);
        header.add(label);

        clientList = new JComboBox<>();
        clientList.setBounds(350, 20, 120, 30);
        header.add(clientList);

        frame.add(header);

        chatPanel = new JPanel(new BorderLayout());
        chatPanel.setBounds(5, 75, 490, 500);
        JScrollPane scrollPane = new JScrollPane(verticalBox);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        chatPanel.add(scrollPane, BorderLayout.CENTER);
        frame.add(chatPanel);

        textField = new JTextField();
        textField.setBounds(5, 580, 350, 40);
        frame.add(textField);

        JButton sendBtn = new JButton("Send to All");
        sendBtn.setBounds(360, 580, 130, 40);
        sendBtn.addActionListener(e -> {
            String message = textField.getText().trim();
            if (!message.isEmpty()) {
                broadcastMessage("Server: " + message);
                textField.setText("");
            }
        });
        frame.add(sendBtn);

        JButton disconnectBtn = new JButton("Disconnect");
        disconnectBtn.setBounds(180, 630, 120, 30);
        disconnectBtn.addActionListener(e -> {
            String selectedUser = (String) clientList.getSelectedItem();
            if (selectedUser != null) {
                disconnectClient(selectedUser);
            }
        });
        frame.add(disconnectBtn);

        frame.setVisible(true);
    }

    public static void main(String[] args) {
        try {
            new Server();
            ServerSocket serverSocket = new ServerSocket(6001);
            System.out.println("Server started on port 6001...");

            while (true) {
                Socket socket = serverSocket.accept();

                DataInputStream din = new DataInputStream(socket.getInputStream());
                DataOutputStream dout = new DataOutputStream(socket.getOutputStream());

                String username = din.readUTF();

                if (username == null || username.trim().isEmpty() || clients.containsKey(username)) {
                    dout.writeUTF("Username invalid or already taken");
                    socket.close();
                    continue;
                }

                ClientHandler handler = new ClientHandler(socket, username, din, dout);
                clients.put(username, handler);

                SwingUtilities.invokeLater(() -> clientList.addItem(username));

                new Thread(handler).start();

                broadcastMessage("Server: " + username + " has joined the chat.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void broadcastMessage(String msg) {
        synchronized (clients) {
            for (ClientHandler client : clients.values()) {
                try {
                    client.send(msg);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        addToChat(msg);
    }

    private static void disconnectClient(String username) {
        ClientHandler client = clients.get(username);
        if (client != null) {
            try {
                client.disconnect();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                clients.remove(username);
                SwingUtilities.invokeLater(() -> clientList.removeItem(username));
                broadcastMessage("Server: " + username + " has been disconnected.");
            }
        }
    }

    private static void addToChat(String message) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel msgLabel = new JLabel("<html><p style='width: 300px'>" + message + "</p></html>");
        msgLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
        msgLabel.setBackground(new Color(37, 211, 102));
        msgLabel.setOpaque(true);
        msgLabel.setBorder(new EmptyBorder(5, 10, 5, 10));

        JLabel timeLabel = new JLabel(new SimpleDateFormat("HH:mm").format(new Date()));
        timeLabel.setFont(new Font("Tahoma", Font.PLAIN, 10));
        timeLabel.setForeground(Color.GRAY);

        panel.add(msgLabel);
        panel.add(timeLabel);

        verticalBox.add(panel);
        verticalBox.add(Box.createVerticalStrut(10));
        chatPanel.revalidate();
        chatPanel.repaint();
    }

    static class ClientHandler implements Runnable {
        private final Socket socket;
        private final String username;
        private final DataInputStream din;
        private final DataOutputStream dout;

        public ClientHandler(Socket socket, String username, DataInputStream din, DataOutputStream dout) {
            this.socket = socket;
            this.username = username;
            this.din = din;
            this.dout = dout;
        }

        public void send(String msg) throws IOException {
            dout.writeUTF(msg);
        }

        public void disconnect() throws IOException {
            send("You have been disconnected by the server.");
            socket.close();
        }

        @Override
        public void run() {
            try {
                while (true) {
                    String msg = din.readUTF();
                    if (msg.equalsIgnoreCase("/quit")) {
                        break;
                    }
                    broadcastMessage(username + ": " + msg);
                }
            } catch (IOException e) {
                System.out.println(username + " disconnected.");
            } finally {
                try {
                    din.close();
                    dout.close();
                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                clients.remove(username);
                SwingUtilities.invokeLater(() -> clientList.removeItem(username));
                broadcastMessage("Server: " + username + " left the chat.");
            }
        }
    }
}
